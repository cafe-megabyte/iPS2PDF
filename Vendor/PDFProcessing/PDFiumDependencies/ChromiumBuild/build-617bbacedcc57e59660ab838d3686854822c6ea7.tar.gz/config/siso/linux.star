# -*- bazel-starlark -*-
# Copyright 2023 The Chromium Authors
# Use of this source code is governed by a BSD-style license that can be
# found in the LICENSE file.
"""Siso configuration for linux."""

load("@builtin//struct.star", "module")
load("./android.star", "android")
load("./clang_linux.star", "clang")
load("./config.star", "config")
load("./cros.star", "cros")
load("./devtools_frontend.star", "devtools_frontend")
load("./nasm_linux.star", "nasm")
load("./platform.star", "platform")
load("./proto_linux.star", "proto")
load("./reclient.star", "reclient")
load("./v8.star", "v8")

def __filegroups(ctx):
    fg = {}
    fg.update(android.filegroups(ctx))
    fg.update(clang.filegroups(ctx))
    fg.update(cros.filegroups(ctx))
    fg.update(devtools_frontend.filegroups(ctx))
    fg.update(nasm.filegroups(ctx))
    fg.update(proto.filegroups(ctx))
    fg["third_party/perfetto/python:python"] = {
        "type": "glob",
        "includes": ["*.py"],
    }
    fg["third_party/perfetto/src/trace_processor:trace_processor"] = {
        "type": "glob",
        "includes": ["*.py"],
    }
    return fg

def __dump_app_syms(ctx, cmd):
    binary = ctx.fs.canonpath(cmd.args[-2])
    dwo_dir = binary + "-dwo/"
    inputs = []
    if ctx.fs.exists(dwo_dir):
        inputs.append(dwo_dir)
    ctx.actions.fix(inputs = cmd.inputs + inputs)

__handlers = {
    "dump_app_syms": __dump_app_syms,
}
__handlers.update(android.handlers)
__handlers.update(clang.handlers)
__handlers.update(cros.handlers)
__handlers.update(devtools_frontend.handlers)
__handlers.update(nasm.handlers)
__handlers.update(proto.handlers)

def __step_config(ctx, step_config):
    config.check(ctx)

    if android.enabled(ctx):
        step_config = android.step_config(ctx, step_config)

    # cros rules are necessary only for the Siso's builtin RBE client mode.
    if not reclient.enabled(ctx):
        step_config = cros.step_config(ctx, step_config)

    step_config = clang.step_config(ctx, step_config)
    step_config = devtools_frontend.step_config(ctx, step_config)
    step_config = nasm.step_config(ctx, step_config)
    step_config = proto.step_config(ctx, step_config)
    step_config = v8.step_config(ctx, step_config)

    step_config["rules"].extend([
        {
            "name": "write_buildflag_header",
            "command_prefix": platform.python_bin + " ../../build/write_buildflag_header.py",
            "remote": config.get(ctx, "cog") or config.get(ctx, "default-remote"),
            "timeout": "2m",
            "remote_command": platform.remote_python_bin,
        },
        {
            "name": "write_build_date_header",
            "command_prefix": platform.python_bin + " ../../base/write_build_date_header.py",
            "remote": config.get(ctx, "cog") or config.get(ctx, "default-remote"),
            "timeout": "2m",
            "remote_command": platform.remote_python_bin,
        },
        {
            "name": "version_py",
            "command_prefix": platform.python_bin + " ../../build/util/version.py",
            "remote": config.get(ctx, "cog") or config.get(ctx, "default-remote"),
            "timeout": "2m",
            "remote_command": platform.remote_python_bin,
        },
        {
            "name": "perfetto/touch_file",
            "command_prefix": platform.python_bin + " ../../third_party/perfetto/tools/touch_file.py",
            "remote": config.get(ctx, "cog") or config.get(ctx, "default-remote"),
            "replace": True,
            "timeout": "2m",
            "remote_command": platform.remote_python_bin,
        },
        {
            "name": "perfetto/write_buildflag_header",
            "command_prefix": platform.python_bin + " ../../third_party/perfetto/gn/write_buildflag_header.py",
            "remote": config.get(ctx, "cog") or config.get(ctx, "default-remote"),
            "timeout": "2m",
            "remote_command": platform.remote_python_bin,
        },
        {
            "name": "perfetto/gen_tp_table_headers",
            "command_prefix": platform.python_bin + " ../../third_party/perfetto/tools/gen_tp_table_headers.py",
            "inputs": [
                "third_party/perfetto/python:python",
                "third_party/perfetto/src/trace_processor:trace_processor",
            ],
            "remote": config.get(ctx, "cog") or config.get(ctx, "default-remote"),
            "timeout": "2m",
            "remote_command": platform.remote_python_bin,
        },
        {
            "name": "perfetto/gen_cc_proto_descriptor",
            "command_prefix": platform.python_bin + " ../../third_party/perfetto/tools/gen_cc_proto_descriptor.py",
            "remote": config.get(ctx, "cog") or config.get(ctx, "default-remote"),
            "timeout": "2m",
            "remote_command": platform.remote_python_bin,
        },
        {
            # b/331716896: local fails due to link(2) error.
            "name": "generate_fontconfig_cache",
            "command_prefix": platform.python_bin + " ../../build/gn_run_binary.py generate_fontconfig_caches",
            "remote": config.get(ctx, "cog") or config.get(ctx, "default-remote"),
            "timeout": "2m",
            "remote_command": platform.remote_python_bin,
        },
        {
            "name": "dump_app_syms",
            "command_prefix": platform.python_bin + " ../../build/linux/dump_app_syms.py",
            "handler": "dump_app_syms",
            "remote": config.get(ctx, "remote-link") or config.get(ctx, "cog") or config.get(ctx, "default-remote"),
            "platform_ref": "large",
            "timeout": "30m",
            "remote_command": platform.remote_python_bin,
        },
    ])

    return step_config

chromium = module(
    "chromium",
    step_config = __step_config,
    filegroups = __filegroups,
    handlers = __handlers,
)
