# -*- bazel-starlark -*-
# Copyright 2024 The Chromium Authors
# Use of this source code is governed by a BSD-style license that can be
# found in the LICENSE file.
"""Siso configuration for clang/unix."""

load("@builtin//path.star", "path")
load("@builtin//runtime.star", "runtime")
load("@builtin//struct.star", "module")
load("./android.star", "android")
load("./clang_all.star", "clang_all")
load("./config.star", "config")
load("./gn_logs.star", "gn_logs")
load("./platform.star", "platform")
load("./win_sdk.star", "win_sdk")

def __clang_link(ctx, cmd):
    if not (config.get(ctx, "remote-link") or config.get(ctx, "default-remote")):
        return
    inputs = []
    outputs = []
    reconcile_outputdirs = []
    split_dwarf = False
    use_lto = False
    sysroot = ""
    target = ""
    args = cmd.args
    if args[0] == "/bin/sh":
        args = args[2].split(" ")
    for i, arg in enumerate(args):
        if i == 0 and not "python3" in arg:
            clang_base = ctx.fs.canonpath(path.dir(path.dir(arg)))
            inputs.append(clang_base + ":link")
            continue
        if i == 1:
            driver = ctx.fs.canonpath(arg)  # driver script
            if ctx.fs.exists(driver):
                inputs.append(driver + ":link")
            continue
        if arg.startswith("--sysroot="):
            sysroot = arg.removeprefix("--sysroot=")
            sysroot = ctx.fs.canonpath(sysroot)
            inputs.append(sysroot + ":link")
        elif arg == "-isysroot":
            sysroot = ctx.fs.canonpath(args[i + 1])
            inputs.append(sysroot + ":link")
        elif arg.startswith("--target="):
            target = arg.removeprefix("--target=")
        elif arg.startswith("-L"):
            lib_path = ctx.fs.canonpath(arg.removeprefix("-L"))
            inputs.append(lib_path + ":link")
        elif arg.startswith("-Wl,-exported_symbols_list,"):
            export_path = ctx.fs.canonpath(arg.removeprefix("-Wl,-exported_symbols_list,"))
            inputs.append(export_path)
        elif arg == "-sectcreate":
            # -sectcreate <arg1> <arg2> <arg3>
            inputs.append(ctx.fs.canonpath(args[i + 3]))
        elif arg.startswith("-Wcrl,"):
            crls = arg.removeprefix("-Wcrl,").split(",")
            if len(crls) == 2:
                crl = ctx.fs.canonpath(crls[1])
                if ctx.fs.exists(crl):
                    inputs.append(crl + ":link")
        elif arg == "-gsplit-dwarf":
            split_dwarf = True
        elif arg.startswith("-flto"):
            use_lto = True
        elif arg == "--":
            clang_base = ctx.fs.canonpath(path.dir(path.dir(cmd.args[i + 1])))
            inputs.append(clang_base + ":link")

    for arch in android.archs:
        if target.startswith(arch):
            android_ver = target.removeprefix(arch)
            inputs.extend([
                sysroot + "/usr/lib/" + arch + "/" + android_ver + ":link",
            ])
            break

    outputs = cmd.outputs
    reconcile_outputdirs = []
    if split_dwarf and use_lto:
        dwo_dir = cmd.outputs[0] + "-dwo/"
        outputs = cmd.outputs + [dwo_dir]
        reconcile_outputdirs = [dwo_dir]

    ctx.actions.fix(
        inputs = cmd.inputs + inputs,
        outputs = outputs,
        reconcile_outputdirs = reconcile_outputdirs,
    )

__handlers = {}
__handlers.update(clang_all.handlers)
__handlers["clang_link"] = __clang_link

def __rules(ctx):
    gn_logs_data = gn_logs.read(ctx)
    input_root_absolute_path = gn_logs_data.get("clang_need_input_root_absolute_path") == "true"
    input_root_absolute_path_for_objc = gn_logs_data.get("clang_need_input_root_absolute_path_for_objc") == "true"

    # Remote linking with ThinLTO takes much longer.
    # Linking browser_tests takes 50m locally. On remote with gVisor,
    # it takes even more.
    use_thin_lto = gn_logs_data.get("use_thin_lto") == "true"
    remote_link_timeout = "80m" if use_thin_lto else "10m"

    remote_link = config.get(ctx, "remote-link") or config.get(ctx, "default-remote")
    if runtime.os == "darwin":
        remote_link = False

    rules = []
    if win_sdk.enabled(ctx):
        rules.extend([
            {
                "name": "clang-cl/cxx",
                "handler": "clang_compile",
                "action": "(.*_)?cxx",
                "command_prefix": "../../third_party/llvm-build/Release+Asserts/bin/clang-cl ",
                "inputs": [
                    "third_party/llvm-build/Release+Asserts/bin/clang-cl",
                ],
                "exclude_input_patterns": ["*.stamp"],
                "remote": True,
                "input_root_absolute_path": input_root_absolute_path,
                "timeout": "2m",
            },
            {
                "name": "clang-cl/cc",
                "handler": "clang_compile",
                "action": "(.*_)?cc",
                "command_prefix": "../../third_party/llvm-build/Release+Asserts/bin/clang-cl ",
                "inputs": [
                    "third_party/llvm-build/Release+Asserts/bin/clang-cl",
                ],
                "exclude_input_patterns": ["*.stamp"],
                "remote": True,
                "input_root_absolute_path": input_root_absolute_path,
                "timeout": "2m",
            },
            {
                "name": "lld-link/alink",
                "action": "(.*_)?alink",
                "command_prefix": "../../third_party/llvm-build/Release+Asserts/bin/lld-link /lib",
                "handler": "lld_thin_archive",
                "remote": False,
                "accumulate": True,
            },
            {
                "name": "lld-link/solink",
                "action": "(.*_)?solink",
                "command_prefix": "../../third_party/llvm-build/Release+Asserts/bin/lld-link",
                "handler": "lld_link",
                "inputs": [
                    "third_party/llvm-build/Release+Asserts/bin/lld-link",
                    win_sdk.toolchain_dir(ctx) + ":libs",
                ],
                "exclude_input_patterns": [
                    "*.cc",
                    "*.h",
                    "*.js",
                    "*.pak",
                    "*.py",
                ],
                "remote": remote_link,
                "platform_ref": "large",
                "input_root_absolute_path": input_root_absolute_path,
                "timeout": remote_link_timeout,
            },
            {
                "name": "lld-link/solink_module",
                "action": "(.*_)?solink_module",
                "command_prefix": "../../third_party/llvm-build/Release+Asserts/bin/lld-link",
                "handler": "lld_link",
                "inputs": [
                    "third_party/llvm-build/Release+Asserts/bin/lld-link",
                    win_sdk.toolchain_dir(ctx) + ":libs",
                ],
                "exclude_input_patterns": [
                    "*.cc",
                    "*.h",
                    "*.js",
                    "*.pak",
                    "*.py",
                ],
                "remote": remote_link,
                "platform_ref": "large",
                "input_root_absolute_path": input_root_absolute_path,
                "timeout": remote_link_timeout,
            },
            {
                "name": "lld-link/link",
                "action": "(.*_)?link",
                "command_prefix": "../../third_party/llvm-build/Release+Asserts/bin/lld-link",
                "handler": "lld_link",
                "inputs": [
                    "third_party/llvm-build/Release+Asserts/bin/lld-link",
                    win_sdk.toolchain_dir(ctx) + ":libs",
                ],
                "exclude_input_patterns": [
                    "*.cc",
                    "*.h",
                    "*.js",
                    "*.pak",
                    "*.py",
                ],
                "remote": remote_link,
                "platform_ref": "large",
                "input_root_absolute_path": input_root_absolute_path,
                "timeout": remote_link_timeout,
            },
        ])

    rules.extend([
        {
            "name": "clang/cxx",
            "handler": "clang_compile",
            "action": "(.*_)?cxx",
            "command_prefix": "../../third_party/llvm-build/Release+Asserts/bin/clang++ ",
            "inputs": [
                "third_party/llvm-build/Release+Asserts/bin/clang++",
            ],
            "exclude_input_patterns": ["*.stamp"],
            "remote": True,
            "input_root_absolute_path": input_root_absolute_path,
            "timeout": "2m",
        },
        {
            "name": "clang/cxx_module",
            "handler": "clang_compile",
            "action": "(.*_)?cxx_module",
            "command_prefix": "../../third_party/llvm-build/Release+Asserts/bin/clang++ ",
            "inputs": [
                "third_party/llvm-build/Release+Asserts/bin/clang++",
            ],
            "exclude_input_patterns": ["*.stamp"],
            "remote": True,
            "input_root_absolute_path": input_root_absolute_path,
            "timeout": "2m",
        },
        {
            "name": "clang/cc",
            "handler": "clang_compile",
            "action": "(.*_)?cc",
            "command_prefix": "../../third_party/llvm-build/Release+Asserts/bin/clang ",
            "inputs": [
                "third_party/llvm-build/Release+Asserts/bin/clang",
            ],
            "exclude_input_patterns": ["*.stamp"],
            "remote": True,
            "input_root_absolute_path": input_root_absolute_path,
            "timeout": "2m",
        },
        {
            "name": "clang/objcxx",
            "handler": "clang_compile",
            "action": "(.*_)?objcxx",
            "command_prefix": "../../third_party/llvm-build/Release+Asserts/bin/clang++",
            "inputs": [
                "third_party/llvm-build/Release+Asserts/bin/clang++",
            ],
            "exclude_input_patterns": ["*.stamp"],
            "remote": True,
            "timeout": "2m",
            "input_root_absolute_path": input_root_absolute_path_for_objc,
        },
        {
            "name": "clang/objc",
            "handler": "clang_compile",
            "action": "(.*_)?objc",
            "command_prefix": "../../third_party/llvm-build/Release+Asserts/bin/clang",
            "inputs": [
                "third_party/llvm-build/Release+Asserts/bin/clang",
            ],
            "exclude_input_patterns": ["*.stamp"],
            "remote": True,
            "timeout": "2m",
            "input_root_absolute_path": input_root_absolute_path_for_objc,
        },
        {
            "name": "clang/asm",
            "handler": "clang_compile",
            "action": "(.*_)?asm",
            "command_prefix": "../../third_party/llvm-build/Release+Asserts/bin/clang",
            "inputs": [
                "third_party/llvm-build/Release+Asserts/bin/clang",
            ],
            # Remote assembly is typically much slower than local assembly.
            # However, on Cog, local actions incur the overhead of fetching the
            # toolchain and all inputs, making remote execution preferable.
            "remote": config.get(ctx, "cog") or config.get(ctx, "default-remote"),
            "input_root_absolute_path": input_root_absolute_path,
            "timeout": "2m",
        },
        {
            "name": "clang-coverage/cxx",
            "action": "(.*_)?cxx",
            "command_prefix": platform.python_bin + " ../../build/toolchain/clang_code_coverage_wrapper.py",
            "inputs": [
                "third_party/llvm-build/Release+Asserts/bin/clang++",
            ],
            "exclude_input_patterns": ["*.stamp"],
            "handler": "clang_compile_coverage",
            "remote": True,
            "input_root_absolute_path": input_root_absolute_path,
            "timeout": "2m",
        },
        {
            "name": "clang-coverage/cc",
            "action": "(.*_)?cc",
            "command_prefix": platform.python_bin + " ../../build/toolchain/clang_code_coverage_wrapper.py",
            "inputs": [
                "third_party/llvm-build/Release+Asserts/bin/clang",
            ],
            "exclude_input_patterns": ["*.stamp"],
            "handler": "clang_compile_coverage",
            "remote": True,
            "input_root_absolute_path": input_root_absolute_path,
            "timeout": "2m",
        },
        {
            "name": "clang-coverage/objcxx",
            "action": "(.*_)?objcxx",
            "command_prefix": platform.python_bin + " ../../build/toolchain/clang_code_coverage_wrapper.py",
            "inputs": [
                "third_party/llvm-build/Release+Asserts/bin/clang++",
            ],
            "exclude_input_patterns": ["*.stamp"],
            "handler": "clang_compile_coverage",
            "remote": True,
            "timeout": "2m",
            "input_root_absolute_path": input_root_absolute_path_for_objc,
        },
        {
            "name": "clang-coverage/objc",
            "action": "(.*_)?objc",
            "command_prefix": platform.python_bin + " ../../build/toolchain/clang_code_coverage_wrapper.py",
            "inputs": [
                "third_party/llvm-build/Release+Asserts/bin/clang",
            ],
            "exclude_input_patterns": ["*.stamp"],
            "handler": "clang_compile_coverage",
            "remote": True,
            "timeout": "2m",
            "input_root_absolute_path": input_root_absolute_path_for_objc,
        },
        {
            "name": "clang/alink/llvm-ar",
            "action": "(.*_)?alink",
            "exclude_input_patterns": [
                "*.cc",
                "*.h",
                "*.js",
                "*.pak",
                "*.py",
                "*.stamp",
            ],
            "handler": "lld_thin_archive",
            "remote": remote_link,
            "timeout": "2m",
            "platform_ref": "large",
            "accumulate": True,
        },
        {
            "name": "clang/solink",
            "action": "(.*_)?solink",
            "handler": "clang_link",
            "inputs": [
                "third_party/cpython3/linux-amd64:cpython3",
            ],
            "exclude_input_patterns": [
                "*.cc",
                "*.h",
                "*.js",
                "*.pak",
                "*.stamp",
            ],
            "remote": remote_link,
            "remote_command": platform.remote_python_bin,
            "restat_content": True,
            "platform_ref": "large",
            "timeout": remote_link_timeout,
        },
        {
            "name": "clang/solink_module",
            "action": "(.*)?solink_module",
            "handler": "clang_link",
            "exclude_input_patterns": [
                "*.cc",
                "*.h",
                "*.js",
                "*.pak",
                "*.stamp",
            ],
            "remote": remote_link,
            "platform_ref": "large",
            "timeout": remote_link_timeout,
        },
        {
            "name": "clang/link",
            "action": "(.*_)?link",
            "handler": "clang_link",
            "inputs": [
                "third_party/cpython3/linux-amd64:cpython3",
            ],
            "exclude_input_patterns": [
                "*.cc",
                "*.h",
                "*.info",
                "*.js",
                "*.pak",
                "*.stamp",
            ],
            "remote": remote_link,
            "remote_command": platform.remote_python_bin,
            "platform_ref": "large",
            "timeout": remote_link_timeout,
        },
    ])
    return rules

def __filegroups(ctx):
    return clang_all.filegroups(ctx)

def __input_deps(ctx):
    return clang_all.input_deps(ctx)

clang_unix = module(
    "clang_unix",
    handlers = __handlers,
    rules = __rules,
    filegroups = __filegroups,
    input_deps = __input_deps,
)
