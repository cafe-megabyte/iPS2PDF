# -*- bazel-starlark -*-
# Copyright 2023 The Chromium Authors
# Use of this source code is governed by a BSD-style license that can be
# found in the LICENSE file.
"""Siso configuration for proto/linux."""

load("@builtin//struct.star", "module")
load("./config.star", "config")
load("./platform.star", "platform")

def __filegroups(ctx):
    return {}

def __step_config(ctx, step_config):
    remote_run = config.get(ctx, "googlechrome")  # Turn this to False when you do file access trace.
    step_config["rules"].extend([
        {
            "name": "proto/protoc_wrapper",
            "command_prefix": platform.python_bin + " ../../tools/protoc_wrapper/protoc_wrapper.py",
            "exclude_input_patterns": [
                "*.o",
                "*.a",
                "*.h",
                "*.cc",
                # "*_pb2.py",
            ],
            "remote": remote_run,
            "remote_command": platform.remote_python_bin,
            # chromeos generates default.profraw?
            "ignore_extra_output_pattern": ".*default.profraw",
            # "deps": "depfile",
            "output_local": True,
            "timeout": "2m",
        },
    ])
    return step_config

proto = module(
    "proto",
    step_config = __step_config,
    filegroups = __filegroups,
    handlers = {},
)
