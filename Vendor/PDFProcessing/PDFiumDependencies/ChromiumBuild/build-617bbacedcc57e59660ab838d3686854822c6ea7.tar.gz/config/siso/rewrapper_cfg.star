# -*- bazel-starlark -*-
# Copyright 2023 The Chromium Authors
# Use of this source code is governed by a BSD-style license that can be
# found in the LICENSE file.
"""Siso configuration for parsing rewrapper cfg file."""

load("@builtin//struct.star", "module")
load("./config.star", "config")

def __parse(ctx, cfg_file):
    if not cfg_file:
        fail("cfg file expected but none found")
    if not ctx.fs.exists(cfg_file):
        fail("looked for rewrapper cfg %s but not found, is download_remoteexec_cfg set in gclient custom_vars?" % cfg_file)

    rewrapper_config = {}
    for line in str(ctx.fs.read(cfg_file)).splitlines():
        if line.startswith("canonicalize_working_dir="):
            rewrapper_config["canonicalize_working_dir"] = line.removeprefix("canonicalize_working_dir=").lower() == "true"

        rewrapper_config["download_outputs"] = True
        if line.startswith("download_outputs="):
            rewrapper_config["download_outputs"] = line.removeprefix("download_outputs=").lower() == "true"

        if line.startswith("exec_strategy="):
            exec_strategy = line.removeprefix("exec_strategy=")

            # Disable racing on builders since bots don't have many CPU cores.
            if exec_strategy == "racing" and config.get(ctx, "builder"):
                exec_strategy = "remote_local_fallback"
            rewrapper_config["exec_strategy"] = exec_strategy

        if line.startswith("exec_timeout="):
            rewrapper_config["exec_timeout"] = line.removeprefix("exec_timeout=")

        if line.startswith("reclient_timeout="):
            rewrapper_config["reclient_timeout"] = line.removeprefix("reclient_timeout=")

        if line.startswith("inputs="):
            rewrapper_config["inputs"] = line.removeprefix("inputs=").split(",")

        if line.startswith("labels="):
            if "labels" not in rewrapper_config:
                rewrapper_config["labels"] = dict()
            for label in line.removeprefix("labels=").split(","):
                label_parts = label.split("=")
                if len(label_parts) != 2:
                    fail("not k,v %s" % label)
                rewrapper_config["labels"][label_parts[0]] = label_parts[1]

        if line.startswith("platform="):
            if "platform" not in rewrapper_config:
                rewrapper_config["platform"] = dict()
            for label in line.removeprefix("platform=").split(","):
                label_parts = label.split("=")
                if len(label_parts) != 2:
                    fail("not k,v %s" % label)
                rewrapper_config["platform"][label_parts[0]] = label_parts[1]

        if line.startswith("remote_wrapper="):
            rewrapper_config["remote_wrapper"] = line.removeprefix("remote_wrapper=")

        if line.startswith("server_address="):
            rewrapper_config["server_address"] = line.removeprefix("server_address=")

        if line.startswith("toolchain_inputs="):
            rewrapper_config["toolchain_inputs"] = line.removeprefix("toolchain_inputs=").split(",")
    return rewrapper_config

rewrapper_cfg = module(
    "rewrapper_cfg",
    parse = __parse,
)
