// Copyright 2017 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

package org.chromium.incrementalinstall;

import android.app.Instrumentation;

/** Exists to support an app having multiple instrumentations. */
public final class SecondInstrumentation extends Instrumentation {}
