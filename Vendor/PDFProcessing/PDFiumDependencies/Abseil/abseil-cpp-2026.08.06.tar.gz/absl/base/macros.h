//
// Copyright 2017 The Abseil Authors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// -----------------------------------------------------------------------------
// File: macros.h
// -----------------------------------------------------------------------------
//
// This header file defines the set of language macros used within Abseil code.
// For the set of macros used to determine supported compilers and platforms,
// see absl/base/config.h instead.
//
// This code is compiled directly on many platforms, including client
// platforms like Windows, Mac, and embedded systems.  Before making
// any changes here, make sure that you're not breaking any platforms.

#ifndef ABSL_BASE_MACROS_H_
#define ABSL_BASE_MACROS_H_

#include <atomic>
#include <cassert>
#include <cstddef>

#include "absl/base/attributes.h"
#include "absl/base/config.h"
#include "absl/base/optimization.h"
#include "absl/base/options.h"
#include "absl/base/port.h"

// ABSL_ARRAYSIZE()
//
// Returns the number of elements in an array as a compile-time constant, which
// can be used in defining new arrays. If you use this macro on a pointer by
// mistake, you will get a compile-time error.
//
// NOTE: Avoid using this macro. Instead, use std::size(a) if possible, or
// std::extent_v<decltype(a)> otherwise.
#define ABSL_ARRAYSIZE(array) \
  (sizeof(::absl::macros_internal::ArraySizeHelper(array)))

namespace absl {
ABSL_NAMESPACE_BEGIN
namespace macros_internal {
// Note: this internal template function declaration is used by ABSL_ARRAYSIZE.
// The function doesn't need a definition, as we only use its type.
template <typename T, size_t N>
auto ArraySizeHelper(const T (&array)[N]) -> char (&)[N];
}  // namespace macros_internal

namespace base_internal {
#if ABSL_HAVE_CPP_ATTRIBUTE(clang::nomerge)
[[clang::nomerge]]  // Needed when this function is not inlined
#endif
[[noreturn]] inline void HardeningAbort() {
#if ABSL_HAVE_CPP_ATTRIBUTE(clang::nomerge)
  [[clang::nomerge]]  // Needed when this function is inlined
#endif
  ABSL_INTERNAL_IMMEDIATE_ABORT_IMPL();
  ABSL_INTERNAL_UNREACHABLE_IMPL();
}
}  // namespace base_internal
ABSL_NAMESPACE_END
}  // namespace absl

// ABSL_INTERNAL_UNEVALUATED()
//
// Expands into a no-op expression that contains the given expression. Used to
// avoid unused-variable warnings in configurations that don't need to evaluate
// the given expression (e.g., NDEBUG).
#if ABSL_INTERNAL_CPLUSPLUS_LANG >= 202002L
// We use `decltype` here to avoid generating unnecessary code that the
// optimizer then has to optimize away.
// This not only improves compilation performance by reducing codegen bloat
// and optimization work, but also guarantees fast run-time performance without
// having to rely on the optimizer.
#define ABSL_INTERNAL_UNEVALUATED(expr) (decltype((void)(expr))())
#else
// Pre-C++20, lambdas can't be inside unevaluated operands, so we're forced to
// rely on the optimizer.
#define ABSL_INTERNAL_UNEVALUATED(expr) (false ? (void)(expr) : void())
#endif

// ABSL_BAD_CALL_IF()
//
// Used on a function overload to trap bad calls: any call that matches the
// overload will cause a compile-time error. This macro uses a clang-specific
// "enable_if" attribute, as described at
// https://clang.llvm.org/docs/AttributeReference.html#enable-if
//
// Overloads which use this macro should be bracketed by
// `#ifdef ABSL_BAD_CALL_IF`.
//
// Example:
//
//   int isdigit(int c);
//   #ifdef ABSL_BAD_CALL_IF
//   int isdigit(int c)
//     ABSL_BAD_CALL_IF(c <= -1 || c > 255,
//                       "'c' must have the value of an unsigned char or EOF");
//   #endif // ABSL_BAD_CALL_IF
#if ABSL_HAVE_ATTRIBUTE(enable_if)
#define ABSL_BAD_CALL_IF(expr, msg) \
  __attribute__((enable_if(expr, "Bad call trap"), unavailable(msg)))
#endif

// ABSL_ASSERT()
//
// In C++11, `assert` can't be used portably within constexpr functions.
// `assert` also generates spurious unused-symbol warnings.
// ABSL_ASSERT functions as a runtime assert but works in C++11 constexpr
// functions, and maintains references to symbols.  Example:
//
// constexpr double Divide(double a, double b) {
//   return ABSL_ASSERT(b != 0), a / b;
// }
//
// This macro is inspired by
// https://akrzemi1.wordpress.com/2017/05/18/asserts-in-constexpr-functions/
#if defined(NDEBUG)
#define ABSL_ASSERT(expr) ABSL_INTERNAL_UNEVALUATED((expr) ? void() : void())
#else
#define ABSL_ASSERT(expr)                           \
  (ABSL_PREDICT_TRUE((expr)) ? static_cast<void>(0) \
                             : assert(false && #expr))  // NOLINT
#endif

// `ABSL_INTERNAL_HARDENING_ABORT()` controls how `ABSL_HARDENING_ASSERT()`
// aborts the program in release mode (when NDEBUG is defined). The
// implementation should abort the program as quickly as possible and ideally it
// should not be possible to ignore the abort request.
#if defined(__CUDACC__) || defined(__CUDA_ARCH__) || defined(__CUDA__)
#define ABSL_INTERNAL_HARDENING_ABORT()   \
  do {                                    \
    ABSL_INTERNAL_IMMEDIATE_ABORT_IMPL(); \
    ABSL_INTERNAL_UNREACHABLE_IMPL();     \
  } while (false)
#else
#define ABSL_INTERNAL_HARDENING_ABORT() ::absl::base_internal::HardeningAbort()
#endif

// ABSL_HARDENING_ASSERT()
//
// `ABSL_HARDENING_ASSERT()` is like `ABSL_ASSERT()`, but used to implement
// runtime assertions that should be enabled in hardened builds even when
// `NDEBUG` is defined.
//
// When `NDEBUG` is not defined, `ABSL_HARDENING_ASSERT()` is identical to
// `ABSL_ASSERT()`.
//
// See `ABSL_OPTION_HARDENED` in `absl/base/options.h` for more information on
// hardened mode.
#if (ABSL_OPTION_HARDENED == 1 || ABSL_OPTION_HARDENED == 2) && defined(NDEBUG)
 #define ABSL_HARDENING_ASSERT(expr)    \
   do {                                 \
     if (!ABSL_PREDICT_TRUE((expr))) {  \
       ABSL_INTERNAL_HARDENING_ABORT(); \
     }                                  \
   } while (false)
#else
#define ABSL_HARDENING_ASSERT(expr) ABSL_ASSERT(expr)
#endif

// ABSL_HARDENING_ASSERT_SLOW()
//
// `ABSL_HARDENING_ASSERT()` is like `ABSL_HARDENING_ASSERT()`,
//  but specifically for assertions whose predicates are too slow
//  to be enabled in many applications.
//
// When `NDEBUG` is not defined, `ABSL_HARDENING_ASSERT_SLOW()` is identical to
// `ABSL_ASSERT()`.
//
// See `ABSL_OPTION_HARDENED` in `absl/base/options.h` for more information on
// hardened mode.
#if ABSL_OPTION_HARDENED == 1 && defined(NDEBUG)
#define ABSL_HARDENING_ASSERT_SLOW(expr) ABSL_HARDENING_ASSERT(expr)
#else
#define ABSL_HARDENING_ASSERT_SLOW(expr) ABSL_ASSERT(expr)
#endif

#ifdef ABSL_HAVE_EXCEPTIONS
#define ABSL_INTERNAL_TRY try
#define ABSL_INTERNAL_CATCH_ANY catch (...)
#define ABSL_INTERNAL_RETHROW do { throw; } while (false)
#else  // ABSL_HAVE_EXCEPTIONS
#define ABSL_INTERNAL_TRY if (true)
#define ABSL_INTERNAL_CATCH_ANY else if (false)
#define ABSL_INTERNAL_RETHROW do {} while (false)
#endif  // ABSL_HAVE_EXCEPTIONS

// ABSL_REFACTOR_INLINE
//
// Marks a function or type for automated refactoring by go/cpp-inliner. It can
// be used on inline function definitions or type aliases in header files and
// should be combined with the `[[deprecated]]` attribute.
//
// Using `ABSL_REFACTOR_INLINE` differs from using the `[[deprecated]]` alone in
// the following ways:
//
// 1. New uses of the function or type will be discouraged via Tricorder
//    warnings.
// 2. If enabled via `METADATA`, automated changes will be sent out inlining the
//    functions's body or replacing the type where it is used.
//
// Examples:
//
// [[deprecated("Use NewFunc() instead")]] ABSL_REFACTOR_INLINE
// inline int OldFunc(int x) {
//   return NewFunc(x, 0);
// }
//
// using OldType [[deprecated("Use NewType instead")]] ABSL_REFACTOR_INLINE =
//     NewType;
//
// will mark `OldFunc` and `OldType` as deprecated, and the go/cpp-inliner
// service will replace calls to `OldFunc(x)` with calls to `NewFunc(x, 0)` and
// `OldType` with `NewType`. Once all replacements have been completed, the old
// function or type can be deleted.
//
// Internal note: Clang also allows `ABSL_REFACTOR_INLINE` to be used on
// using-declarations, but attributes on using-declarations are invalid in C++.
// (NOTE: This note refers to `using a::b ABSL_REFACTOR_INLINE;` and not
// `using b ABSL_REFACTOR_INLINE = a::b;`, which is OK.) Therefore:
//
// 1. In OSS: Do not use this on using-declarations. Such usage is invalid and
//    unsupported usage, and may break at any time.
// 2. In Google: Avoid such usage except as a last resort. Instead, prefer other
//    inlining approaches (such as type aliases or forwarding functions,
//    illustrated above) whenever possible. This is because Clang (currently)
//    does not honor the [[deprecated]] attribute on using-declarations, and
//    therefore cannot surface the deprecation to users in the middle of a
//    migration.
//
// See go/cpp-inliner for more information.
//
// Note: go/cpp-inliner is Google-internal service for automated refactoring.
// While open-source users do not have access to this service, the macro is
// provided for compatibility.
#if ABSL_HAVE_CPP_ATTRIBUTE(clang::annotate)
#define ABSL_REFACTOR_INLINE                                                \
  _Pragma("clang diagnostic push") /* Avoid errors on using-declarations */ \
      _Pragma("clang diagnostic ignored \"-Wcxx-attribute-extension\"")     \
          [[clang::annotate("inline-me")]] _Pragma("clang diagnostic pop")
#else
#define ABSL_REFACTOR_INLINE
#endif

// ABSL_DEPRECATE_AND_INLINE()
//
// This is the original macro used by go/cpp-inliner that combines
// [[deprecated]] and ABSL_REFACTOR_INLINE.
//
// Examples:
//
// ABSL_DEPRECATE_AND_INLINE() inline int OldFunc(int x) {
//   return NewFunc(x, 0);
// }
//
// using OldType ABSL_DEPRECATE_AND_INLINE() = NewType;
//
// The combination of `[[deprecated("Use X instead")]]` and
// `ABSL_REFACTOR_INLINE` is preferred because it provides a more informative
// deprecation message to developers, especially those that do not have access
// to the automated refactoring capabilities of go/cpp-inliner.
// In chromium this macro doesn't add [[deprecated]] attribute as chromium disallows to
// use deprecated code. By removing this attribute other third party libraries get more
// time to migrate from deprecated api to something newer.
#define ABSL_DEPRECATE_AND_INLINE() ABSL_REFACTOR_INLINE

// Requires the compiler to prove that the size of the given object is at least
// the expected amount.
#if ABSL_HAVE_ATTRIBUTE(diagnose_if) && ABSL_HAVE_BUILTIN(__builtin_object_size)
#define ABSL_INTERNAL_NEED_MIN_SIZE(Obj, N)                     \
  __attribute__((diagnose_if(__builtin_object_size(Obj, 0) < N, \
                             "object size provably too small "  \
                             "(this would corrupt memory)",     \
                             "error")))
#else
#define ABSL_INTERNAL_NEED_MIN_SIZE(Obj, N)
#endif

#endif  // ABSL_BASE_MACROS_H_
